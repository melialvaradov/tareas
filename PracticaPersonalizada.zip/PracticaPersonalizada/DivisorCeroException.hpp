#ifndef DIVISOR_CERO_EXCEPTION_HPP
#define DIVISOR_CERO_EXCEPTION_HPP

#include <exception>
#include <string>
using namespace std;

class DivisorCeroException : public exception {
private:
    string mensaje;

public:
    DivisorCeroException(const string& msg) { mensaje = msg; }
    const char* what() const noexcept override { return mensaje.c_str(); }
};

#endif // DIVISOR_CERO_EXCEPTION_HPP